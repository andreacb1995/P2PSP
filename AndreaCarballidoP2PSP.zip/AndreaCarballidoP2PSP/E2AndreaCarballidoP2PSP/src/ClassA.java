import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class ClassA extends Thread {
	private static int counter;
	private static Set<Long> threadIds = new HashSet<Long>();

	@SuppressWarnings("static-access")
	public ClassA(int cnt) {
		this.counter = cnt;
	}

	public void run() {
		EnterAndWait();

	}

	public static boolean isFinished() {
		if (counter == 0) {
			return true;
		} else {
			return false;
		}
	}

	public synchronized static void EnterAndWait() {
		Long id = Thread.currentThread().getId();
		System.out.println("Soy el hilo " + id + " y estoy empezando a ejecutar el m�todo EnterAndWait()");
		counter--;

		threadIds.add(id);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}

		System.out.println("Soy el hilo " + id + " y estoy acabando de ejecutar el m�todo EnterAndWait()");
		

	}

	public static Set<Long> recuperarThreadIds() {
		return threadIds;
	}
	
	   public static void idsHilos() {
	       
	        String ids=null;
	       
	        for(Long id : threadIds) {
	            ids=String.valueOf(id);
	            System.out.println("Hilo "+ids);
	        }
	    }
	   
	   

}