import java.util.LinkedList;

//Modifica ClassB: Modifica el m�todo run() implementar la condici�n de exclusi�n condicional
//con wait() y notify()/notifyAll(). Los hilos deben ejecutarse continuamente hasta que el objeto
//de la ClassA compartido indique que ha finalizado. B�sicamente, ahora, cada hilo debe de
//hacer lo siguiente: llamar al m�todo wait() del objeto compartido y esperar a ser despertado
//para continuar la ejecuci�n. Cuando es despertado, debe comprobar si todav�a es posible
//ejecutar en el enterAndWait() y, en ese caso, ejecutarlo. Antes de ponerse a dormir de
//nuevo, el hilo debe avisar al siguiente hilo con notify()/notifyAll().

public class ClassB implements Runnable {
	LinkedList<ClassB> lista = new LinkedList<ClassB>();
	ClassA objetoClassA;
	ClassB next;
	boolean finalizado = true;

	public ClassA getObjetoClassA() {
		return objetoClassA;
	}

	public void setObjetoClassA(ClassA objetoClassA) {
		this.objetoClassA = objetoClassA;
	}

	public ClassB getNext() {
		return next;
	}

	public void setNext(ClassB next) {
		this.next = next;
	}

	public boolean isFinalizado() {
		return finalizado;
	}

	public void setFinalizado(boolean finalizado) {
		this.finalizado = finalizado;
	}

	ClassB(ClassA classA) {
		this.objetoClassA = classA;

	}

	@Override
	public void run() {
		while (finalizado) {
			synchronized (this) {
				try {
					wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (ClassA.isFinished()) {
					finalizado = false;
					
				} else {
					ClassA.EnterAndWait();
				}
				synchronized (next) {
					next.notify();
					
				}

			}

		}

	}

}