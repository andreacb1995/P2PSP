import java.util.ArrayList;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Main {

	public static void main(String[] args) throws InterruptedException {

		String tecla = null;
		int opcionFinal = 0;
		do {
			int nHilos = 0;
			int counter = 0;
			System.out.println("Empezamos el programa");
			Scanner entradaEscaner = new Scanner(System.in);

			boolean salir = false;
			int opcion = 0; // Guardaremos la opcion del usuario
			boolean volver = false;
			Set<Long> listaIdsEntran = new HashSet<Long>();
			Set<Long> listaIdsNoEntran = new HashSet<Long>();

			while (!salir) {

				try {
					System.out.println("Por favor introduzca el numero de hilos que quiere ejecutar:");
					nHilos = entradaEscaner.nextInt();
					salir = true;
				} catch (InputMismatchException ex) {
					System.out.println("Debe introducir un numero.");
					entradaEscaner.next();
				}
			}
			salir = false;
			while (!salir) {
				try {
					System.out.println(
							"Por favor introduzca el número de accesos totales, de hilos que quiere ejecutar en la sección crítica:");
					counter = entradaEscaner.nextInt();
					salir = true;
				} catch (InputMismatchException ex) {
					System.out.println("Debe introducir un numero.");
					entradaEscaner.next();
				}
			}

			salir = false;
			
			while (!salir) {
				System.out.println("Seleccione una opción");
			System.out.println("1. Ejecutar el programa con Notify()");
			System.out.println("2. Ejecutar el programa con NotifyAll()");
				try {

					opcion = entradaEscaner.nextInt();
					salir = true;

				} catch (InputMismatchException e) {
					System.out.println("Debe insertar un número");
					entradaEscaner.next();
				}
			}

			switch (opcion) {

			case 1:
				System.out.println("Has seleccionado la opcion 1");

				System.out.println("Ejecutando el programa...");
				Thread.sleep(2000);
				Thread thread = null;
				LinkedList<ClassB> lista = new LinkedList<ClassB>();
				ClassA classA = new ClassA(counter);

				// Creación de la ClassB
				for (int i = 0; i < nHilos; i++) {
					ClassB classB = new ClassB(classA);
					lista.add(classB);
				}

				Set<Long> listaIdsCreados = new HashSet<Long>();

				for (ClassB classb : lista) {
					thread = new Thread(classb);
					listaIdsCreados.add(thread.getId());

					thread.start();
				}

				for (int i = 0; i < lista.size(); i++) {

					if (lista.size() == i + 1) {
						lista.getLast().setNext(lista.getFirst());

					} else {
						lista.get(i).setNext(lista.get(i + 1));

					}

				}

				synchronized (lista.getFirst()) {
					lista.getFirst().notify();
				}

				try {
					thread.join();
				} catch (InterruptedException e) {
					System.out.println("El hilo se ha interrumpido.");
					e.getMessage();
				} catch (NullPointerException i) {
					System.out.println("El hilo es null.");
					i.getMessage();
				}

				Thread.sleep(2000);
				System.out.println("\nHilos creados: ");
				for (long id : listaIdsCreados) {
					System.out.println("Hilo " + id);
				}

				Thread.sleep(2000);

				listaIdsEntran = ClassA.recuperarThreadIds();
				System.out.println("\nHilos que entran en la seccion crítica: ");
				for (long id : listaIdsEntran) {
					System.out.println("Hilo " + id);
				}

				for (final Long element : listaIdsCreados) {
					if (listaIdsEntran.contains(element)) {

					} else {
						listaIdsNoEntran.add(element);
					}
				}

				Thread.sleep(2000);
				if (listaIdsNoEntran.isEmpty()) {
					System.out.println("\nTodos los hilos creados entran en la sección crítica");
				} else {
					System.out.println("\nHilos que no entran en la sección crítica:");
					for (Long idNoEntra : listaIdsNoEntran) {
						System.out.println("Hilo " + idNoEntra);
					}
				}

				System.out.println(" ");
				listaIdsEntran.clear();
				salir=true;
				break;

			case 2:

				break;

			default:
				System.out.println("Debe insertar 1 o 2");
				entradaEscaner.next();
			}
			salir=false;
			while (!salir) {
				try {
					System.out.println("Desea volver a empezar el programa?");
					System.out.println("1.Si");
					System.out.println("2.Salir");
					opcionFinal = entradaEscaner.nextInt();
					salir = true;
					if (opcionFinal == 2) {
						System.out.println("Saliendo del programa...");
						salir = true;
					}
				} catch (InputMismatchException e) {
					System.out.println("Debe insertar un número");
					entradaEscaner.next();
				}

			}

		} while (opcionFinal == 1);

	}

}
